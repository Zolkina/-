import sys
from PyQt6.QtSql import QSqlQuery, QSqlDatabase, QSqlTableModel
from PyQt6.QtWidgets import QMainWindow, QDialog, QLineEdit, QVBoxLayout, QApplication, QMessageBox, QPushButton, QLabel, QTableView, QComboBox
from PyQt6.QtGui import QPalette, QColor
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction
class Admin(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Кино")
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(228, 212, 187))
        self.setPalette(palette)
        self.setGeometry(700, 300, 400, 300)

        # Создание верхнего меню
        menu_bar = self.menuBar()

        # Меню "Киноафиша"
        movie_menu = menu_bar.addMenu("Киноафиша")

        add_session_action = QAction("Добавить сеанс", self)
        add_session_action.triggered.connect(self.add_session)
        movie_menu.addAction(add_session_action)

        delete_session_action = QAction("Удалить сеанс", self)
        delete_session_action.triggered.connect(self.delete_session)
        movie_menu.addAction(delete_session_action)

        show_movie_schedule_action = QAction("Вывести киноафишу", self)
        show_movie_schedule_action.triggered.connect(self.show_movie_schedule)
        movie_menu.addAction(show_movie_schedule_action)

        # Меню "Фильмы"
        films_menu = menu_bar.addMenu("Фильмы")

        add_movie_action = QAction("Добавить фильм", self)
        add_movie_action.triggered.connect(self.add_movie)
        films_menu.addAction(add_movie_action)

        delete_movie_action = QAction("Удалить фильм", self)
        delete_movie_action.triggered.connect(self.delete_movie)
        films_menu.addAction(delete_movie_action)

        show_movies_action = QAction("Вывести фильмы", self)
        show_movies_action.triggered.connect(self.show_movies)
        films_menu.addAction(show_movies_action)

        # Меню "Клиенты"
        clients_menu = menu_bar.addMenu("Клиенты")

        show_clients_action = QAction("Список клиентов", self)
        show_clients_action.triggered.connect(self.show_clients)
        clients_menu.addAction(show_clients_action)

    def add_session(self):
        dialog = QDialog()
        dialog.setWindowTitle("Добавить сеанс")

        # Создание полей для ввода информации о сеансе
        film_label = QLabel("Фильм:")
        film_edit = QLineEdit()
        cinema_label = QLabel("Кинозал:")
        cinema_edit = QLineEdit()
        start_datetime_label = QLabel("Дата и время начала (ГГГГ-ММ-ДД ЧЧ:ММ:СС):")
        start_datetime_edit = QLineEdit()
        price_label = QLabel("Цена:")
        price_edit = QLineEdit()

        # Создание кнопки "Добавить"
        add_button = QPushButton("Добавить")

        self.db = QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("myDB.db")
        if not self.db.open():
            QMessageBox.critical(None, "Ошибка", "Не удалось установить соединение с базой данных.")

        def add_session_to_database():
            # Получение введенных значений
            film = film_edit.text()
            cinema = cinema_edit.text()
            start_datetime = start_datetime_edit.text()
            price = price_edit.text()

            if film and cinema and start_datetime and price:
                query = QSqlQuery()
                query.prepare('''INSERT INTO Sessions (film_id, cinema_id, start_datetime, price)
                                         VALUES (?, ?, ?, ?)''')
                query.addBindValue(film)
                query.addBindValue(cinema)
                query.addBindValue(start_datetime)
                query.addBindValue(price)

                if query.exec():
                    QMessageBox.information(dialog, "Успех", "Сеанс успешно добавлен в базу данных.")
                    dialog.accept()
                else:
                    QMessageBox.critical(dialog, "Ошибка", "Не удалось добавить сеанс в базу данных.")
            else:
                QMessageBox.warning(dialog, "Предупреждение", "Пожалуйста, заполните все поля.")

        add_button.clicked.connect(add_session_to_database)

        # Размещение виджетов на диалоговом окне
        layout = QVBoxLayout()
        layout.addWidget(film_label)
        layout.addWidget(film_edit)
        layout.addWidget(cinema_label)
        layout.addWidget(cinema_edit)
        layout.addWidget(start_datetime_label)
        layout.addWidget(start_datetime_edit)
        layout.addWidget(price_label)
        layout.addWidget(price_edit)
        layout.addWidget(add_button)

        dialog.setLayout(layout)

        # Отображение диалогового окна
        if dialog.exec() == QDialog.DialogCode.Accepted:
            QMessageBox.information(None, "Успех", "Сеанс успешно добавлен в базу данных.")
        else:
            QMessageBox.information(None, "Отмена", "Добавление сеанса было отменено.")

    def delete_session(self):
        dialog = QDialog()
        dialog.setWindowTitle("Удалить сеанс")

        # Создание поля для ввода идентификатора сеанса для удаления
        session_id_label = QLabel("ID сеанса:")
        session_id_edit = QLineEdit()

        # Создание кнопки "Удалить"
        delete_button = QPushButton("Удалить")

        self.db = QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("myDB.db")
        if not self.db.open():
            QMessageBox.critical(None, "Ошибка", "Не удалось установить соединение с базой данных.")

        def delete_session_from_database():
            # Получение введенного идентификатора сеанса для удаления
            session_id = session_id_edit.text()

            if session_id:
                query = QSqlQuery()
                query.prepare("DELETE FROM Sessions WHERE id = ?")
                query.addBindValue(session_id)

                if query.exec():
                    QMessageBox.information(dialog, "Успех", "Сеанс успешно удален из базы данных.")
                    dialog.accept()
                else:
                    QMessageBox.critical(dialog, "Ошибка", "Не удалось удалить сеанс из базы данных.")
            else:
                QMessageBox.warning(dialog, "Предупреждение", "Пожалуйста, введите ID сеанса для удаления.")

        delete_button.clicked.connect(delete_session_from_database)

        # Размещение виджетов на диалоговом окне
        layout = QVBoxLayout()
        layout.addWidget(session_id_label)
        layout.addWidget(session_id_edit)
        layout.addWidget(delete_button)

        dialog.setLayout(layout)

        # Отображение диалогового окна
        if dialog.exec() == QDialog.DialogCode.Accepted:
            QMessageBox.information(None, "Успех", "Сеанс успешно удален из базы данных.")
        else:
            QMessageBox.information(None, "Отмена", "Удаление сеанса было отменено.")

    def show_movie_schedule(self):
        self.db = QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("myDB.db")
        # Создание модели данных
        model = QSqlTableModel(self)
        # Установка таблицы
        model.setTable("Sessions")
        # Установка сортировки по идентификатору
        model.setSort(0, Qt.SortOrder.AscendingOrder)
        # Получение данных
        model.select()
        # Создание и настройка виджета таблицы
        table_view = QTableView(self)
        table_view.setModel(model)
        # Отображение таблицы
        self.setCentralWidget(table_view)

    def add_movie(self):
        dialog = QDialog()
        dialog.setWindowTitle("Добавить фильм")

        # Создание полей для ввода информации о сеансе
        title_label = QLabel("Название фильма:")
        title_edit = QLineEdit()
        director_label = QLabel("Режисер:")
        director_edit = QLineEdit()
        genre_label = QLabel("Жанр:")
        genre_edit = QLineEdit()
        agelimit_label = QLabel("Возрастное ограничение:")
        agelimit_edit = QLineEdit()
        duration_label = QLabel("Длительность:")
        duration_edit = QLineEdit()
        realase_label = QLabel("Год выпуска:")
        realase_edit = QLineEdit()

        # Создание кнопки "Добавить"
        add_button = QPushButton("Добавить")

        self.db = QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("myDB.db")
        if not self.db.open():
            QMessageBox.critical(None, "Ошибка", "Не удалось установить соединение с базой данных.")

        def add_session_to_database():
            # Получение введенных значений
            title = title_edit.text()
            director = director_edit.text()
            genre = genre_edit.text()
            age_limit = agelimit_edit.text()
            duration = duration_edit.text()
            realase_year = realase_edit.text()

            if title and director and genre and age_limit and duration and realase_year:
                query = QSqlQuery()
                query.prepare('''INSERT INTO Films (title, director, genre, age_limit, duration, release_year)
                                                 VALUES (?, ?, ?, ?, ?, ?)''')
                query.addBindValue(title)
                query.addBindValue(director)
                query.addBindValue(genre)
                query.addBindValue(age_limit)
                query.addBindValue(duration)
                query.addBindValue(realase_year)

                if query.exec():
                    QMessageBox.information(dialog, "Успех", "Фильм успешно добавлен в базу данных.")
                    dialog.accept()
                else:
                    QMessageBox.critical(dialog, "Ошибка", "Не удалось добавить фильм в базу данных.")
            else:
                QMessageBox.warning(dialog, "Предупреждение", "Пожалуйста, заполните все поля.")

        add_button.clicked.connect(add_session_to_database)

        # Размещение виджетов на диалоговом окне
        layout = QVBoxLayout()
        layout.addWidget(title_label)
        layout.addWidget(title_edit)
        layout.addWidget(director_label)
        layout.addWidget(director_edit)
        layout.addWidget(genre_label)
        layout.addWidget(genre_edit)
        layout.addWidget(agelimit_label)
        layout.addWidget(agelimit_edit)
        layout.addWidget(duration_label)
        layout.addWidget(duration_edit)
        layout.addWidget(realase_label)
        layout.addWidget(realase_edit)
        layout.addWidget(add_button)

        dialog.setLayout(layout)

        # Отображение диалогового окна
        if dialog.exec() == QDialog.DialogCode.Accepted:
            QMessageBox.information(None, "Успех", "Фильм успешно добавлен в базу данных.")
        else:
            QMessageBox.information(None, "Отмена", "Добавление сеанса было отменено.")

    def delete_movie(self):
        dialog = QDialog()
        dialog.setWindowTitle("Удалить фильм")

        # Создание поля для ввода идентификатора сеанса для удаления
        session_id_label = QLabel("ID фильма:")
        session_id_edit = QLineEdit()

        # Создание кнопки "Удалить"
        delete_button = QPushButton("Удалить")

        self.db = QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("myDB.db")
        if not self.db.open():
            QMessageBox.critical(None, "Ошибка", "Не удалось установить соединение с базой данных.")

        def delete_session_from_database():
            # Получение введенного идентификатора сеанса для удаления
            session_id = session_id_edit.text()

            if session_id:
                query = QSqlQuery()
                query.prepare("DELETE FROM Films WHERE id = ?")
                query.addBindValue(session_id)

                if query.exec():
                    QMessageBox.information(dialog, "Успех", "Фильм успешно удален из базы данных.")
                    dialog.accept()
                else:
                    QMessageBox.critical(dialog, "Ошибка", "Не удалось удалить фильм из базы данных.")
            else:
                QMessageBox.warning(dialog, "Предупреждение", "Пожалуйста, введите ID фильма для удаления.")

        delete_button.clicked.connect(delete_session_from_database)

        # Размещение виджетов на диалоговом окне
        layout = QVBoxLayout()
        layout.addWidget(session_id_label)
        layout.addWidget(session_id_edit)
        layout.addWidget(delete_button)

        dialog.setLayout(layout)

        # Отображение диалогового окна
        if dialog.exec() == QDialog.DialogCode.Accepted:
            QMessageBox.information(None, "Успех", "Фильм успешно удален из базы данных.")
        else:
            QMessageBox.information(None, "Отмена", "Удаление фильма было отменено.")

    def show_movies(self):
        self.db = QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("myDB.db")
        # Создание модели данных
        model = QSqlTableModel(self)
        # Установка таблицы
        model.setTable("Films")
        # Установка сортировки по идентификатору
        model.setSort(0, Qt.SortOrder.AscendingOrder)
        # Получение данных
        model.select()
        # Создание и настройка виджета таблицы
        table_view = QTableView(self)
        table_view.setModel(model)
        # Отображение таблицы
        self.setCentralWidget(table_view)

    def show_clients(self):
        self.db = QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("myDB.db")
        # Создание модели данных
        model = QSqlTableModel(self)
        # Установка таблицы
        model.setTable("Bookings")
        # Установка сортировки по идентификатору
        model.setSort(0, Qt.SortOrder.AscendingOrder)
        # Получение данных
        model.select()
        # Создание и настройка виджета таблицы
        table_view = QTableView(self)
        table_view.setModel(model)
        # Отображение таблицы
        self.setCentralWidget(table_view)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    cinema_app = Admin()
    cinema_app.show()
    sys.exit(app.exec())